package com.snhu.sslserver;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
class SslServerApplicationTests {

	@Value("${server.ssl.enabled}")
	private boolean sslEnabled;

	@Value("${server.port}")
	private int serverPort;

	@Test
	void contextLoads() {
		assertTrue(sslEnabled);
		assertEquals(8443, serverPort);
	}

	@Test
	void createsExpectedSha256Checksum() {
		assertEquals("b3f2f51954adf32fd5ddf244c85fd8c459695bc6cb66193872c470d429698f00",
				ChecksumController.sha256(ChecksumController.DATA));
	}

}
