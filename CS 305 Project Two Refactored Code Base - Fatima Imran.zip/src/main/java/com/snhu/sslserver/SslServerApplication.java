package com.snhu.sslserver;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}

@RestController
class ChecksumController {

	static final String DEVELOPER_NAME = "Fatima Imran";
	static final String DATA = "Artemis Financial | Fatima Imran | Secure Transfer 2026-08-15";

	@GetMapping(value = "/hash", produces = MediaType.TEXT_HTML_VALUE)
	String getChecksum() {
		return "<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\">"
				+ "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
				+ "<title>Artemis Financial Checksum</title>"
				+ "<style>body{font-family:Arial,sans-serif;max-width:880px;margin:64px auto;padding:0 24px;"
				+ "color:#17202a}h1{color:#153e66}.result{border-left:5px solid #1f7a5a;background:#f1f7f5;"
				+ "padding:20px 24px;margin-top:24px}code{overflow-wrap:anywhere;font-size:15px}</style>"
				+ "</head><body><h1>Artemis Financial Secure Checksum</h1>"
				+ "<p><strong>Developer:</strong> " + DEVELOPER_NAME + "</p>"
				+ "<p><strong>Unique data string:</strong> " + DATA + "</p>"
				+ "<div class=\"result\"><p><strong>Algorithm:</strong> SHA-256</p>"
				+ "<p><strong>Checksum:</strong><br><code>" + sha256(DATA) + "</code></p></div>"
				+ "</body></html>";
	}

	static String sha256(String value) {
		try {
			MessageDigest digest = MessageDigest.getInstance("SHA-256");
			byte[] encodedHash = digest.digest(value.getBytes(StandardCharsets.UTF_8));
			StringBuilder hex = new StringBuilder(encodedHash.length * 2);
			for (byte currentByte : encodedHash) {
				hex.append(String.format("%02x", currentByte & 0xff));
			}
			return hex.toString();
		} catch (NoSuchAlgorithmException exception) {
			throw new IllegalStateException("SHA-256 is not available", exception);
		}
	}
}
